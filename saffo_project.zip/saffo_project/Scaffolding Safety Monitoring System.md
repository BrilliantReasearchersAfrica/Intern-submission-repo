#  Scaffolding Safety Monitoring System

An **IoT-based embedded safety system** using **ESP32**, designed to **monitor scaffold stability** on construction sites by detecting **tilt, vibration**, and triggering **LED/buzzer alarms** while transmitting data to a **web dashboard** and **supervisor via IFTTT alerts**.

---

##  Problem Statement

Construction scaffolds can tilt, collapse, or vibrate due to structural instability or external factors like wind or machinery. This project aims to prevent accidents by:

- Continuously monitoring scaffold **tilt angle**
- Detecting dangerous **vibrations**
- Triggering **audible/visual alarms**
- Sending alerts to a **supervisor's email**
- Displaying real-time data on a **web dashboard**

---

##  Features

 Monitor **tilt angle** using MPU6050  
 Detect **vibration** using accelerometer data  
 **Green / Yellow / Red LEDs** show safety status  
 **Buzzer** beeps or alarms for warnings/danger  
 **Web interface** (auto-refreshing) for live status  
 **IFTTT alert**: sends email when status is *DANGER* or vibration is high  
 **Modular Arduino code** (clean, scalable)

---

##  Hardware Components

| Component     | Qty | Description                      |
|---------------|-----|----------------------------------|
| ESP32 Dev Kit | 1   | Wi-Fi microcontroller            |
| MPU6050       | 1   | 3-axis Accelerometer + Gyroscope |
| Green LED     | 1   | Status: Normal                   |
| Yellow LED    | 1   | Status: Warning                  |
| Red LED       | 1   | Status: Danger                   |
| Buzzer        | 1   | Audible alarm                    |
| Resistors     | 3   | 220Ω for LEDs                    |
| Jumper wires  | —   | For connections                  |
| Breadboard    | 1   | For prototyping                  |

---

##  Wiring Diagram

### MPU6050 to ESP32:
| MPU6050 | ESP32 Pin |
|---------|-----------|
| VCC     | 3.3V      |
| GND     | GND       |
| SDA     | GPIO 21   |
| SCL     | GPIO 22   |

### Outputs:
| Device   | ESP32 Pin |
|----------|-----------|
| Green LED  | GPIO 15 |
| Yellow LED | GPIO 2  |
| Red LED    | GPIO 4  |
| Buzzer     | GPIO 5  |

> All LEDs should be connected via 220Ω resistors to GND.

---

##  Code Structure

| File                | Description                            |
|---------------------|----------------------------------------|
| `scaffold_safety.ino` | Main Arduino sketch                  |
| `/code/`            | Folder containing modular code         |
| `/diagrams/`        | Fritzing or wiring images              |
| `README.md`         | Project overview and setup guide       |

---

##  System Behavior

| Tilt Angle     | LED         | Buzzer         | Status   |
|----------------|-------------|----------------|----------|
| ≤ 5°           | Green ON    | Off            | NORMAL   |
| 5° - 10°       | Yellow Blink| Short Beep     | WARNING  |
| > 10°          | Red Blink   | Continuous Tone| DANGER   |

- **Vibration Level:** Triggers extra alert if it exceeds a threshold
- **Web Server:** Shows tilt, vibration, and status (auto-refreshes)
- **IFTTT Alert:** Sends email when DANGER or high vibration is detected

---

##  Web Dashboard

- Auto-refreshes every 2 seconds
- Shows live:
  - Tilt Angle
  - Vibration Level
  - System Status

---

##  IFTTT Email Alert Integration

- Triggered via HTTP GET request from ESP32
- Requires IFTTT account and Webhook applet:
